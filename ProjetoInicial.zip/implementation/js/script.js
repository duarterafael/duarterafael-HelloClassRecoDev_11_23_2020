function calcularIMC() {
    var pesoInput = document.querySelector("#peso");
    var alturaInput = document.querySelector("#altura"); 
    var resultado = document.querySelector("#resposta");
    var classificacaoOutput = document.querySelector("#classificacao");
    

}

